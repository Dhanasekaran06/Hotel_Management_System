﻿'---------------------------------------
'Programmed by: Jomar I. Pabuaya
'Website: http://www.sourcecodester.com
'---------------------------------------

Module modPublicVar
    Public CurrUser As USER_INFO
    Public CurrBiz As BUSINESS_INFO
    Public CurrCust As Customer
End Module
