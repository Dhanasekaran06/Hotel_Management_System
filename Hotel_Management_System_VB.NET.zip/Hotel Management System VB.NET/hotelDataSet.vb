﻿

Partial Public Class hotelDataSet
End Class
